<?php

/*
MalaysiaWAP Project
Release By: LaN89
E-Mail: malaysiawap@gmail.com
Website: http://www.malaysiawap.net
*/

include("inc/func.inc.php");
$a = $_GET["a"];
$ref = $_GET["ref"];
$i = $_GET["i"];
$p = $_GET["p"];
$w = $_GET["w"];
$do = $_GET["do"];
$page = "xhtml";
$title = "MalaysiaWAP";
$u = session($_SESSION["session"]);
$path = "index.php";
$extension = "php";

if($page=="wml"){
$drop = false;
}else{
$drop = true;
}



if(($a != "") && ($a != "register") && ($a != "logout") && ($ref != "help") && ($ref != "tc")){
if((islogin($_SESSION["session"])==false)||($u==0)){
//echo "You need to login first for use this features";
header('Location: index.php');
unset($_SESSION["session"]);
//$theme->FootDiv();
//$theme->Div("Foot");
exit();
}
}


$theme = new HTML();
$theme->Themes();
$theme->Div("container");
$theme->Div("Logo");
echo "MalaysiaWAP";
$theme->Div("D", true);


if(!db()){
echo "Error to connect database. Please try again later";
$theme->FootDiv();
$theme->Div("Foot");
exit();
}



if($a==""){
require("_SRC/home.php");
}else if(file_exists("_SRC/$a.php")){
require("_SRC/$a.php");
}else{
require("_SRC/home.php");
}
$theme->Div("D");


$theme->FootDiv();
$theme->Div("Foot");
exit();
?>
