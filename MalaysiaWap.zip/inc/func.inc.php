<?php

include_once("inc/init.php");
db();

function db(){
$conms = @mysql_connect(DB_SERVER,DB_USER,DB_PASS); //connect mysql
if(!$conms) return false;
$condb = @mysql_select_db(DB_DATABASE);
if(!$condb) return false;
return true;
}



function getPage($page){
if($page=="wml"){
$ret = Form::WML;
}else{
$ret = Form::XHTML;
}
return $ret;
}


function regchars($word){
$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
for($i=0;$i<strlen($word);$i++){
$ch = substr($word,$i,1);
$nol = substr_count($chars,$ch);
if($nol==0){
return true;
}
}
return false;
}

function nospace($word){
$pos = strpos($word," ");
if($pos === false){
return false;
}else{
return true;
}
}

function checknumber($word){
$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$ch = substr($word,0,1);
$sres = ereg("[0-9]",$ch);
$ch = substr($word,0,1);
$nol = substr_count($chars,$ch);
if($nol==0){
return true;
}
return false;
}


function checknick($nick){
$check = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE username='".$nick."'"));
$char = array('fuck', 'babi');
foreach ($char as $word){
$nosf = substr_count(strtolower($nick),$word);
if($nosf>0){
return true;
}
}
if($check[0]>0){
return true;
}

return false;
}


function checkmail($email){
$regexp = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$";
if (eregi($regexp, $email))  {
return true;
}else{
return false;
}
}

function emailexist($email){
$checkmail = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE email='".$email."'"));
if($checkmail[0]>0){
return true;
}else{
return false;
}
}

function clean($str) {
$str = @trim($str);
if(get_magic_quotes_gpc()) {
$str = stripslashes($str);
}
return mysql_real_escape_string($str);
}


function isuser($u){
$cus = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE id='".$u."'"));
if($cus[0]>0){
return true;
}
return false;
}

function islogin($s){
//delete old sessions first
$oses = mysql_query("DELETE FROM session WHERE time<'".time()."'");
//does sessions exist?
$sesx = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM session WHERE id='".$s."'"));
if($sesx[0]>0){
if(!isuser(session($s))){
return false;
}
//yip it's logged in
//first extend its session expirement time
$xtm = time() + (1*60*20);
$extxtm = mysql_query("UPDATE session SET time='".$xtm."' WHERE id='".$s."'");
return true;
}else{
//nope its session must be expired or something
return false;
}
}


function isonline($u){
$on = mysql_fetch_array(mysql_query("SELECT * FROM online WHERE user='".$u."'"));
$count = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM online WHERE user='".$u."'"));


$remain = time() - $on[actvtime];
if($remain<30*60){
return 1;
}else if(($remain>30*60)&&($count[0]==1)){
return 2;
}else if($count[0]==0){
return 0;
}
}


function ontime($u){
$on = mysql_fetch_array(mysql_query("SELECT lactive FROM users WHERE id='".$u."'"));
//$on = mysql_fetch_array(mysql_query("SELECT actvtime FROM online WHERE user='".$u."'"));
return $on[0];
}

function session($s){
$uid = mysql_fetch_array(mysql_query("SELECT user FROM session WHERE id='".$s."'"));
$uid = $uid[0];
return $uid;
}

function id_name($w, $u="", $isyou=FALSE){
$uid = mysql_fetch_array(mysql_query("SELECT username FROM users WHERE id='".$w."'"));
if(($w==$u)&&($isyou==TRUE)){
$uid = "You";
}else{
$uid = $uid[0];
}
return $uid;
}

function name_id($name){
$uid = mysql_fetch_array(mysql_query("SELECT id FROM users WHERE username='".$name."'"));
$uid = $uid[0];
return $uid;
}


function getip(){
if (isset($_SERVER)){
if(isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
if(strpos($ip,",")){
$exp_ip = explode(",",$ip);
$ip = $exp_ip[0];
}
}else if(isset($_SERVER["HTTP_CLIENT_IP"])){
$ip = $_SERVER["HTTP_CLIENT_IP"];
}else{
$ip = $_SERVER["REMOTE_ADDR"];
}
}else{
if(getenv('HTTP_X_FORWARDED_FOR')){
$ip = getenv('HTTP_X_FORWARDED_FOR');
if(strpos($ip,",")){
$exp_ip=explode(",",$ip);
$ip = $exp_ip[0];
}
}else if(getenv('HTTP_CLIENT_IP')){
$ip = getenv('HTTP_CLIENT_IP');
}else {
$ip = getenv('REMOTE_ADDR');
}
}
return $ip; 
}


function getbrowser(){
if (isset($_SERVER)){
$browserA = explode("(",$_SERVER["HTTP_USER_AGENT"]); 
$browserB = explode(")",$browserA[1]);
$browser = $browserA[0]."(".$browserB[0]." ".$browserB[1].")";
}else{
$browserA = explode("(",getenv("HTTP_USER_AGENT")); 
$browserB = explode(")",$browserA[1]);
$browser = $browserA[0]."(".$browserB[0]." ".$browserB[1].")";
}

return $browser; 

}


function getoribrowser($_mob_browser){
if(preg_match('/(google|bot)/i',strtolower($_mob_browser))){
$position = strpos(strtolower($_mob_browser),"bot");
$_mob_browser = substr($_mob_browser, $position-30, $position+2);
$_browser = explode (" ", $_mob_browser);
$_browser = array_reverse($_browser); 
}else if (isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])) {
$_mob_browser = $_SERVER['HTTP_X_OPERAMINI_PHONE_UA'];
$_position=strpos(strtolower($_mob_browser),"nokia");
if($_position)$_mob_browser = substr($_mob_browser, $_position,25);
$_browser = explode ("/", $_mob_browser);
}else {
$_position=strpos(strtolower($_mob_browser),"nokia");
if($_position)$_mob_browser = substr($_mob_browser, $_position,25);
$_browser = explode ("/", $_mob_browser);
}
return $_browser[0];
}

function OS($user_agent){
$exp = explode(" ", $user_agent);
$oses = array (
'Windows 3.11' => 'Win16',
'Windows 95' => '(Windows 95)|(Win95)|(Windows_95)',
'Windows 98' => '(Windows 98)|(Win98)',
'Windows 2000' => '(Windows NT 5.0)|(Windows 2000)',
'Windows XP' => '(Windows NT 5.1)|(Windows XP)',
'Windows Vista' => '(Windows NT 6.0)|(Windows Vista)',
'Windows 7' => '(Windows NT 6.1)|(Windows 7)',
'Windows 2003' => '(Windows NT 5.2)',
'Windows NT 4.0' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
'Windows ME' => 'Windows ME',
'Open BSD'=>'OpenBSD',
'Sun OS'=>'SunOS',
'Linux'=>'(Linux)|(X11)',
'Macintosh'=>'(Mac_PowerPC)|(Macintosh)',
'QNX'=>'QNX',
'BeOS'=>'BeOS',
'OS/2'=>'OS/2',
'Palm OS'=>'Palm OS',
'Search Bot'=>'(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp/cat)|(msnbot)|(ia_archiver)',
'J2ME-Opera Mini'=>'Opera Mini',
'SonyE'=>'J2ME-MIDP',
'Symbian OS'=>'Symbian OS',
'SymbianOS 6.1'=>'SymbianOS/6.1',
'SymbianOS 7.0'=>'SymbianOS/7.0',
'SymbianOS 8.0'=>'SymbianOS/8.0',
'SymbianOS 9.1'=>'SymbianOS/9.1',
'SymbianOS 9.2'=>'SymbianOS/9.2',
'SymbianOS 9.4'=>'SymbianOS/9.4',
'Mac OS (iPhone)'=>'iPhone',
'Windows CE' => 'Windows CE'
);

foreach($oses as $os=>$pattern){
if (eregi($pattern, $user_agent))
return $os;
}
return 'Unknown';
}


function smilies($text){
$sql = "SELECT * FROM smilies";
$smilies = mysql_query($sql);
while($smilie=mysql_fetch_array($smilies)){
//$text = str_replace($smilie[code],"<img src=\"./smilies/$smilie[source]\" alt=\"*\"/>",$text);
$code = $smilie[code];
$path = $smilie[source];
$text = str_replace($code,"<img src=\"./smilies/$path\" alt=\"$code\"/>",$text);
}
return $text;
}


function parsetext($text){
$text = htmlentities(stripslashes($text));
//$text = WrapText($text, 50);
$text = bbcode($text, 1);
$text = str_replace(chr(13),"<br/>",$text);
return $text;
}

function WrapText($string, $max){

$text = explode(" ", $string);

foreach($text as $i=>$w){

if(strlen($text[$i])>$max){

$text[$i]=wordwrap($text[$i], $max, " ", 1);

}
}
return implode(" ",$text);

}

function myTruncate($string, $limit, $break=" ", $pad="..."){
// return with no change if string is shorter than $limit
if(strlen($string) <= $limit) return $string;
$string = substr($string, 0, $limit);
if(false !== ($breakpoint = strrpos($string, $break))){
$string = substr($string, 0, $breakpoint);
}
return $string . $pad;
}

function bbcode($text, $filtered){
global $extension, $u;
//$text = htmlspecialchars($text);
$text=preg_replace("/\[b\](.*?)\[\/b\]/i","<b>\\1</b>", $text);
$text=preg_replace("/\[i\](.*?)\[\/i\]/i","<i>\\1</i>", $text);
$text=preg_replace("/\[u\](.*?)\[\/u\]/i","<u>\\1</u>", $text);
$text=preg_replace("/\[st\](.*?)\[\/st\]/i","<strike>\\1</strike>", $text);
$text=preg_replace("/\[B\](.*?)\[\/B\]/i","<big>\\1</big>", $text);
$text=preg_replace("/\[s\](.*?)\[\/s\]/i","<small>\\1</small>", $text);
$text = preg_replace("/\[url\=(.*?)\](.*?)\[\/url\]/is","<a href=\"$1\">$2</a>",$text);
$text = preg_replace("/\[gallery\=(.*?)\](.*?)\[\/gallery\]/is","<a href=\"gallery.$extension?a=info&amp;i=$1\">$2</a>",$text);
$text = preg_replace("/\[room\=(.*?)\](.*?)\[\/room\]/is","<a href=\"chat.$extension?a=e&amp;r=$1\">$2</a>",$text);
$text = preg_replace("/\[topic\=(.*?)\](.*?)\[\/topic\]/is","<a href=\"forum.$extension?a=read&amp;i=$1\">$2</a>",$text);
$text = preg_replace("/\[user\=(.*?)\](.*?)\[\/user\]/is","<a href=\"profile.$extension?a=m&amp;w=$1\">$2</a>",$text);
$text = preg_replace("/\[blog\=(.*?)\](.*?)\[\/blog\]/is","<a href=\"blog.$extension?a=more&amp;i=$1\">$2</a>",$text);
$text = preg_replace("/\[survey\=(.*?)\](.*?)\[\/survey\]/is","<a href=\"survey.$extension?a=vote&amp;w=$1\">$2</a>",$text);
$text = str_replace("[br/]","<br/>",$text);
if(substr_count($text,"[br/]")<=10){
$text = str_replace("[br/]","<br/>",$text);
}
$sml = mysql_fetch_array(mysql_query("SELECT smilies FROM users WHERE id='".$u."'"));
if($sml[0]==1){
$text = smilies($text);
}
return $text;
}


function remaining($time, $idle){
$remain = time() - $time;
if($remain>$idle){
$result = "<small><i>".date("(H:i A) D , d M y", $time)."</i></small>";
}else{
$result = "<small><i>".idle(time(), $time)."</i></small>";
}

return $result;

}


function idle($fromTime, $toTime = 0, $showLessThanAMinute = true) {
$distanceInSeconds = round(abs($toTime - $fromTime));
$distanceInMinutes = round($distanceInSeconds / 60);



if ( $distanceInMinutes <= 1 ) {
if ( !$showLessThanAMinute ) {
return ($distanceInMinutes == 0) ? 'less than a minute ago' : '1 minute';
} else {
if ( $distanceInSeconds < 5 ) {
return 'less than 5 seconds ago';
}
if ( $distanceInSeconds < 10 ) {
return 'less than 10 seconds ago';
}
if ( $distanceInSeconds < 20 ) {
return 'less than 20 seconds ago';
}
if ( $distanceInSeconds < 40 ) {
return 'half a minute ago';
}
if ( $distanceInSeconds < 60 ) {
return 'less than a minute ago';
}
return '1 minute ago';
}
}
if ( $distanceInMinutes < 45 ) {
return $distanceInMinutes . ' minutes ago';
}
if ( $distanceInMinutes < 90 ) {
return 'about 1 hour ago';
}
if ( $distanceInMinutes < 1440 ) {
return 'about ' . round(floatval($distanceInMinutes) / 60.0) . ' hours ago';
}
if ( $distanceInMinutes < 2880 ) {
return '1 day ago';
}
if ( $distanceInMinutes < 43200 ) {
return 'about ' . round(floatval($distanceInMinutes) / 1440) . ' days ago';
}
if ( $distanceInMinutes < 86400 ) {
return 'about 1 month ago';
}
if ( $distanceInMinutes < 525600 ) {
return round(floatval($distanceInMinutes) / 43200) . ' months ago';
}
if ( $distanceInMinutes < 1051199 ) {
return 'about 1 year ago';
}
return 'over ' . round(floatval($distanceInMinutes) / 525600) . ' years ago';
}



function age($strdate){
$dob = explode("-",$strdate);
if(count($dob)!=3){
return 0;
}
$y = $dob[0];
$m = $dob[1];
$d = $dob[2];
if(strlen($y)!=4){
return 0;
}
if(strlen($m)!=2){
return 0;
}
if(strlen($d)!=2){
return 0;
}
$y += 0;
$m += 0;
$d += 0;
if($y==0) return 0;
$rage = date("Y") - $y;
if(date("m")<$m){
$rage-=1;
}else{
if((date("m")==$m)&&(date("d")<$d)){
$rage-=1;
}
}
return $rage;
}



function avatar($u, $w, $h, $alte=""){

if(isonline($u)==1){
$class = "online";
}else if(isonline($u)==2){
$class = "idle";
}else{
$class = "offline"; 
}

if($alte==""){
$alt = "Avatar";
}else{
$alt = $alte;
}



$ava = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE id='".$u."'"));
$sour = preg_match('/.gif/i',$ava[avatar]);
if($ava[avatar]==""){
$avatar = "<img src=\"thumb.php?img=images/noavatar.gif&amp;w=$w&amp;h=$h\" alt=\"$alt\" class=\"$class\"/>";
}else if(!file_exists($ava[avatar])){
$avatar = "<img src=\"thumb.php?img=images/noavatar.gif&amp;w=$w&amp;h=$h\" alt=\"$alt\" class=\"$class\"/>";
}else{
if($sour==1){
$avatar = "<img src=\"".htmlspecialchars($ava[avatar])."\" alt=\"$alt\" width=\"$w\" height=\"$h\" class=\"$class\"/>";
}else{
$avatar = "<img src=\"thumb.php?img=".htmlspecialchars($ava[avatar])."&amp;w=$w&amp;h=$h\" alt=\"$alt\" class=\"$class\"/>";
}


}
return $avatar;
}


function image($src, $w, $h, $alt){

$sour = preg_match('/.gif/i',$src);
if($sour==1){
$img = "<img src=\"$src\" alt=\"$alt\" width=\"$w\" height=\"$h\"/>";
}else{
$img = "<img src=\"thumb.php?img=$src&amp;w=$w&amp;h=$h\" alt=\"$alt\"/>";
}

return $img;
}


function addonline($user,$place,$plink=""){
$hidden=mysql_fetch_array(mysql_query("SELECT hidden FROM users WHERE id='".$user."'"));

if($hidden[0]==0){
/////delete inactive users
$tm = time();
$timeout = $tm - 1*60*60; //time out = 5 minutes
$deloff = mysql_query("DELETE FROM online WHERE actvtime <'".$timeout."'");

///now try to add user to online list
$lastactive = mysql_fetch_array(mysql_query("SELECT lactive FROM users WHERE id='".$user."'"));
$tolsla = (time()) - $lastactive[0];
$totaltimeonline = mysql_fetch_array(mysql_query("SELECT totalonline FROM users WHERE id='".$user."'"));
$totaltimeonline = $totaltimeonline[0] + $tolsla;
$res = mysql_query("UPDATE users SET 
totalonline='".$totaltimeonline."', 
lactive='".time()."', 
browser='".getbrowser()."', 
obrowser='".getoribrowser(getbrowser())."', 
ipadd='".getip()."'  WHERE id='".$user."'");

$res = mysql_query("INSERT INTO online SET user='".$user."', actvtime='".$tm."', place='".$place."', placelink='".$plink."', idle='0'");
if(!$res){
//most probably userid already in the online list
//so just update the place and timea


$remain = time() - $lastactive[0];
if($remain>15*60){
$res = mysql_query("UPDATE online SET idle='1' WHERE user='".$user."'");
}else{
$res = mysql_query("UPDATE online SET actvtime='".$tm."', place='".$place."', placelink='".$plink."', idle='0' WHERE user='".$user."'");
}


}
}

$maxmem = mysql_fetch_array(mysql_query("SELECT value FROM settings WHERE id='2'"));
$result = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM online"));
if($result[0]>=$maxmem[0]){
$tnow = date("D d M Y - H:i:s A");
mysql_query("UPDATE settings set name='".$tnow."', value='".$result[0]."' WHERE id='2'");
}
$maxtoday = mysql_fetch_array(mysql_query("SELECT ppl FROM totalonline WHERE ddt='".date("d m y")."'"));
if($maxtoday[0]==0||$maxtoday==""){
mysql_query("INSERT INTO totalonline SET ddt='".date("d m y")."', ppl='1', dtm='".date("H:i:s")."'");
$maxtoday[0]=1;
}
if($result[0]>=$maxtoday[0]){
mysql_query("UPDATE totalonline SET ppl='".$result[0]."', dtm='".date("H:i:s A")."' WHERE ddt='".date("d m y")."'");
}
}


function isignored($w, $u){
$ign = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM blacklist WHERE who='".$w."' AND user='".$u."'"));
if($ign[0]>0){
return true;
}
return false;
}


function createCaptcha(){
$addOne = rand(1,50);
$addTwo = rand(1,50);
$answer = $addOne+$addTwo;
$Question = "$addOne+$addTwo=?";
$_SESSION['captcha_code'] = $answer;
$_SESSION['captchaAlt'] = $Question;
return true;
}


function spanText($text){
if($text=="s"){
$rep = "Success";
}else if($text=="f"){
$rep = "Failed";
}else{
$rep = "None";
}


if($text=="d"){
$ret = "</span>";
}else{
$ret = "<span id=\"span$rep\">";
}

return $ret;
}


function Birthday($day="01", $month="01", $year="1980"){
$rform = "<select name=\"day\">";
$dayval = range('1','31');
foreach ($dayval as $key){
if($key<10){
$keyadd = "0$key";
}else{
$keyadd = "$key";
}
if($day==$keyadd){
$rform .= "<option value=\"$keyadd\" selected=\"true\">$keyadd</option>";
}else{
$rform .= "<option value=\"$keyadd\">$keyadd</option>";
}
}
$rform .= "</select> ";
$rform .= "<select name=\"month\">";
$monthval = array('1'=>'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
foreach ($monthval as $val => $months){
if($val<10){
$keyadd = "0$val";
}else{
$keyadd = "$val";
}
if($month==$keyadd){
$rform .= "<option value=\"$keyadd\" selected=\"true\">$months</option>";
}else{
$rform .= "<option value=\"$keyadd\">$months</option>";
}
}
$rform .= "</select> ";
$rform .= "<select name=\"year\">";
$yearval = range('1950','2009');
foreach ($yearval as $key){
if($year==$key){
$rform .= "<option value=\"$key\" selected=\"true\">$key</option>";
}else{
$rform .= "<option value=\"$key\">$key</option>";
}
}
$rform .= "</select>";
return $rform;
}

?>