<?php

// Include File //
include_once("inc/config.inc.php");
include_once("inc/message.inc.php");

// Class File //
include_once("class/class.theme.php");
include_once("class/class.database.php");
include_once("class/class.form.php");
include_once("class/class.user.php");
include_once("class/class.inbox.php");

/*
include_once("lib/config.php");
include_once("lib/core.php");
include_once("lib/fbconnect.php");
include_once("lib/user.php");
include_once("lib/display.php");
include_once("lib/friends.php");
include_once("lib/run.php");


include("facebook-client/facebook.php");
include("facebook-client/facebook_mobile.php");


include_once MAIN_PATH.'/lib/config.php';
include_once MAIN_PATH.'/lib/core.php';
include_once MAIN_PATH.'/lib/fbconnect.php';
include_once MAIN_PATH.'/lib/user.php';
include_once MAIN_PATH.'/lib/display.php';
include_once MAIN_PATH.'/lib/friends.php';
include_once MAIN_PATH.'/lib/run.php';
include_once MAIN_PATH.'/facebook-client/facebook.php';
include_once MAIN_PATH.'/facebook-client/facebook_mobile.php';
*/