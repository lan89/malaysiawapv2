<?php

function MessageCase($case){
switch($case){
case 1:
$text = "Database not connected";
return $text;
break;
case 2:
$text = "Invalid Login ID";
return $text;
break;
case 3:
$text = "Invalid password";
return $text;
break;
case 4:
$text = "Login ID doest exists";
return $text;
break;
case 5:
$text = "Invalid Login ID or password";
return $text;
break;


}

}



function errorSQL(){
$text = "Could not connect to server or clone data submit";
return $text;
}
?>
