<?php

class User{



function Register($user, $fname, $lname, $pass, $repass, $email, $reemail, $gender, $birthdate, $captcha){
if(trim($user)==""){
$ret = "Login ID cant be empty";
}else if(trim($fname)==""){
$ret = "First name cant be empty";
}else if((trim($pass)=="")||(trim($repass)=="")){
$ret = "Password and retype password cant be empty";
}else if((strlen($pass)<4)||(strlen($pass)>21)){
$ret = "Password must be 4 character to 20 characters";
}else if((strlen($user)<4)||(strlen($user)>21)){
$ret = "Username must be 4 character to 20 characters";
}else if((regchars($user))||(nospace($user))||(checknumber($user))){
$ret = "Username invalid or reserved";
}else if(checknick($user)){
$ret = "Username already taken";
}else if($pass!=$repass){
$ret = "Password and retype password must be same";
}else if(trim($email=="")){
$ret = "Please field your email address";
}else if(checkmail($email)==false){
$ret = "Invalid email address>";
}else if($email!=$reemail){
$ret = "Password and retype password must be same";
}else if(emailexist($email)==true){
$ret = "Email already in used";
}else if($captcha!= $_SESSION["captcha_code"]){
$ret = "Captcha code not match";
}else{

$res = mysql_query("INSERT INTO users SET 
username='".$user."', 
fname='".$fname."', 
lname='".$lname."', 
password='".md5($pass)."', 
email='".$email."', 
gender='".$gender."', 
birthdate='".$birthdate."', 
regdate='".time()."',
browser='".getbrowser()."',
obrowser='".getoribrowser(getbrowser())."',
ipadd='".getip()."'

");
if($res){
$ret = "Thanks for registering with us. Now you can login and update your profile before sign in.";
}else{
$ret = errorSQL();
}

}


return $ret;
}



function Status($text){
global $u;
$already = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM status WHERE text LIKE '".$text."' AND user='".$u."'"));
if(trim($text)==""){
$ret = "".spanText("f")."Status message cant be empty".spanText("d")."";
}else if($already[0]>0){
$ret = "".spanText("f")."Status already posted".spanText("d")."";

}else{

$res = mysql_query("INSERT INTO status SET 
user='".$u."', 
text='".$text."', 
sent='".time()."'
");
if($res){
$ret = "Status updated";
}else{
$ret = errorSQL();
}
}


return $ret;
}

function AddComment($table, $text, $i){
global $u;
if(trim($text)==""){
$ret = "Status message cant be empty";
}else{

$res = mysql_query("INSERT INTO $table SET 
who='".$u."', 
text='".$text."', 
refid='".$i."', 
sent='".time()."'
");
if($res){
$ret = "Comment added successfully";
}else{
$ret = errorSQL();
}
}

return $ret;
}


function AddLike($table, $i){
global $u;
$already = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM $table WHERE refid='".$i."'"));

if($already[0]==1){
$ret = "You already like this";
}else{
$res = mysql_query("INSERT INTO $table SET 
who='".$u."', 
refid='".$i."', 
sent='".time()."'
");
if($res){
$ret = "You like this";
}else{
$ret = errorSQL();
}
}
return $ret;
}



function RemoveLike($table, $i){
global $u;

$res = mysql_query("DELETE FROM $table WHERE 
id='".$i."'
");
if($res){
$ret = "You unlike this";
}else{
$ret = errorSQL();
}

return $ret;
}

function CountTable($table, $i){
$ret = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM $table WHERE refid='".$i."'"));
return $ret[0];
}

}


