<?php
/*
**Script Name: Form Maker class
**Purpose: A class to generate xhtml and wml forms code
**Script Written By: Ra'ed Shabanah 2008 (c)
**E-mail: raed_mfs@yahoo.com
**COPYRIGHTS 

**This script was written fully by Ra'ed Shabanah, Senjil - Palestine
**use it as you wish,you can edit it.. etc 
*/

class Form
{
var $fields =Array();
var $options= Array();
var $action;
var $method="post";
const TYPE_TEXT = 0;
const TYPE_PASS = 1;
const TYPE_SLCT = 2;
const TYPE_HIDN = 3;
const TYPE_SBMT = 4;
const TYPE_TXTA = 5; //text area
const XHTML = 0;
const WML = 1;

function addField($caption, $name, $type, $maxlength=0, $value="", $size=0)
{
$c = count($this->fields);
$this->fields[$c] = Array('caption'=>$caption, 'name'=>$name, 'type'=>$type, 'maxlength'=>$maxlength, 'value'=>$value, 'size'=>$size);
return $c;
}
function addOption($field, $name, $value, $xh)
{
$c = count($this->options);
$this->options[$c] = Array('field'=>$field, 'name'=>$name, 'value'=>$value, 'xh'=>$xh);
return $c;
}

function setAction($href)
{
$this->action=$href;
}
function setMethod($meth)
{
$this->method = $meth;
}
function getCode($output_type)
{
if($output_type==self::XHTML)
{
$code = '<form action="'.$this->action.'" method="'.$this->method.'">';
for($i=0;$i<count($this->fields); $i++)
{
switch($this->fields[$i]['type'])
{
case self::TYPE_TEXT:
$code .= $this->fields[$i]['caption'].':<br/><input type="text" name="'.$this->fields[$i]['name'].'"'.($this->fields[$i]['maxlength']>0?' maxlength="'.$this->fields[$i]['maxlength'].'"':'').''.($this->fields[$i]['size']>0?' size="'.$this->fields[$i]['size'].'"':'').''.(trim($this->fields[$i]['value'])!=""?' value="'.$this->fields[$i]['value'].'"':'').'/><br/>';
break;
case self::TYPE_PASS:
$code .= $this->fields[$i]['caption'].':<br/><input type="password" name="'.$this->fields[$i]['name'].'"'.($this->fields[$i]['maxlength']>0?' maxlength="'.$this->fields[$i]['maxlength'].'"':'').''.($this->fields[$i]['size']>0?' size="'.$this->fields[$i]['size'].'"':'').''.(trim($this->fields[$i]['value'])!=""?' value="'.$this->fields[$i]['value'].'"':'').'/><br/>';
break;




case self::TYPE_TXTA:
$code .= $this->fields[$i]['caption'].'<br/>
<textarea name="'.$this->fields[$i]['name'].'">
'.$this->fields[$i]['value'].'
</textarea><br/>
';
//'.(trim($this->fields[$i]['value'])!=""?' value="'.$this->fields[$i]['value'].'"':'').'

break;
case self::TYPE_SBMT:
$code .='<input type="submit" name="'.$this->fields[$i]['name'].'" value="'.$this->fields[$i]['caption'].'" class="button" /><br/>
';
break;
case self::TYPE_SLCT:
$code .=$this->fields[$i]['caption'].': <br/>
<select name="'.$this->fields[$i]['name'].'" value="'.$this->fields[$i]['value'].'" >
';
for($j=0; $j<count($this->options); $j++){
if($this->options[$j]['field']==$i){
$code .= '<option value="'.$this->options[$j]['value'].'" '.($this->options[$j]['xh']?($this->fields[$i]['value']==$this->options[$j]['value']?'selected="selected"':''):'').'>'.$this->options[$j]['name'].'</option>';
}
}
$code .= '</select><br/>
';
break;
case self::TYPE_HIDN:
$code .= '<input type="hidden" name="'.$this->fields[$i]['name'].'" '.(trim($this->fields[$i]['value'])!=""?' value="'.$this->fields[$i]['value'].'"':'').'/>';
break;
}
}
$code .= '</form>';
}else{
//wml code
$code ="";
$postfield ="";
for($i=0;$i<count($this->fields); $i++)
{
switch($this->fields[$i]['type'])
{
case self::TYPE_TEXT:
$code .= $this->fields[$i]['caption'].':<br/><input name="'.$this->fields[$i]['name'].'"'.($this->fields[$i]['maxlength']>0?' maxlength="'.$this->fields[$i]['maxlength'].'"':'').''.($this->fields[$i]['size']>0?' size="'.$this->fields[$i]['size'].'"':'').'/><br/>
';
$postfield .= '<postfield name="'.$this->fields[$i]['name'].'" value="$('.$this->fields[$i]['name'].')" />';
break;

case self::TYPE_PASS:
$code .= $this->fields[$i]['caption'].':<br/><input type="password" name="'.$this->fields[$i]['name'].'"'.($this->fields[$i]['maxlength']>0?' maxlength="'.$this->fields[$i]['maxlength'].'"':'').''.($this->fields[$i]['size']>0?' size="'.$this->fields[$i]['size'].'"':'').'/><br/>
';
$postfield .= '<postfield name="'.$this->fields[$i]['name'].'" value="$('.$this->fields[$i]['name'].')" />';
break;



case self::TYPE_TXTA:
$code .= $this->fields[$i]['caption'].':<br/><input name="'.$this->fields[$i]['name'].'"'.($this->fields[$i]['maxlength']>0?' maxlength="'.$this->fields[$i]['maxlength'].'"':'').''.($this->fields[$i]['size']>0?' size="'.$this->fields[$i]['size'].'"':'').'/><br/>';
$postfield .= '<postfield name="'.$this->fields[$i]['name'].'" value="$('.$this->fields[$i]['name'].')" />';
break;

case self::TYPE_SBMT:
$anchor ='
<anchor>'.$this->fields[$i]['caption'].'<go href="'.$this->action.'" method="'.$this->method.'">
<postfield name="'.$this->fields[$i]['name'].'" value="'.$this->fields[$i]['name'].'" />';
break;
case self::TYPE_SLCT:
$code .=$this->fields[$i]['caption'].':<br/> 
<select name="'.$this->fields[$i]['name'].'" value="'.$this->fields[$i]['value'].'" >';
for($j=0; $j<count($this->options); $j++){
if($this->options[$j]['field']==$i){
$code .= '<option value="'.$this->options[$j]['value'].'" '.($this->options[$j]['xh']?($this->fields[$i]['value']==$this->options[$j]['value']?'selected="selected"':''):'').'>'.$this->options[$j]['name'].'</option>';
}
}
$code .= '</select><br/>';
$postfield .= '<postfield name="'.$this->fields[$i]['name'].'" value="$('.$this->fields[$i]['name'].')" />';
break;
case self::TYPE_HIDN:
$postfield .= '<postfield name="'.$this->fields[$i]['name'].'" value="'.$this->fields[$i]['value'].'" />';
break;
}
}
$code .= $anchor;
$code .= $postfield;
$code .= '</go></anchor><br/>';
}

return $code;
}



}






?>
