<?php

class db{

function dbQuery($rows,$table,$where=""){
 if(!empty($where))$where=" WHERE $where";
$sql=mysql_query("SELECT $rows FROM $table$where");
return $sql;
}

function dbJoinedQuery($rows,$table,$table2,$on,$where=""){
 if(!empty($where))$where=" WHERE $where";
$sql=mysql_query("SELECT $rows FROM $table a INNER JOIN $table2 b ON $on $where");
return $sql;
}

function dbNumRows($rows,$table,$where=""){
 if(!empty($where))$where=" WHERE $where";
$sql=mysql_query("SELECT $rows FROM $table$where");
return mysql_num_rows($sql);
}

function dbFetchArray($row,$table,$where=""){
 if(!empty($where))$where=" WHERE $where";
$sql=mysql_query("SELECT $row FROM $table$where");
$a=mysql_fetch_array($sql);
 if($row!="*")return $a["$row"];
return $a;
}

function dbInsert($table,$set){
$sql=mysql_query("INSERT INTO $table SET $set");
return $sql;
}

function dbUpdate($table,$set,$where){
$sql=mysql_query("UPDATE $table SET $set WHERE $where");
return $sql;
}

function dbDelete($table,$where=""){
 if(!empty($where))$where=" WHERE $where";
$sql=mysql_query("DELETE FROM $table$where");
return $sql;
}

function dbSesTable($row,$sesid){
$a=dbFetchArray("*",m_token,"id='$sesid'");
$b=$a["$row"];
return $b;
}

function dbUsersTable($row,$uid){
$a=dbFetchArray("*",m_users,"id='$uid'");
$b=$a["$row"];
return $b;
}

function dbSelectForm($table,$where="",$row1="",$row2=""){
$obj="\n";
$sql="SELECT * FROM $table";
 if(!empty($where))$sql.=" WHERE $where";
$query=dbQuery("*",$table,$where);
 if(mysql_num_rows($query)>0){
  while($row=dbFetchArray($query)){
  $obj.="<option value=\"$row[$row1]\">$row[$row2]</option>\n";
  }
 }
return $obj;
}

}
?>