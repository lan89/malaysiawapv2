<?php

class HTML{

function H(){
global $page, $u;
if($page=="wml"){
$head = header("Content-type: text/vnd.wap.wml");
$ret .= header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
$ret .= header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
$ret .= header("Cache-Control: no-store, no-cache, must-revalidate");
$ret .= header("Pragma: no-cache");

$ret .= "<?xml version=\"1.0\"?>";
$ret .= "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\"". " \"http://www.wapforum.org/DTD/wml_1.1.xml\">";
$ret .= "<wml>";
}else{
$ret = header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
$ret .= header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
$ret .= header("Cache-Control: no-cache, must-revalidate");
$ret .= header("Pragma: no-cache");
$ret .= "<?xml version=\"1.0\"?>\n";
$ret .= "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">\n";
//$head .= "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
$ret .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
}
return $ret;
}


function T(){
global $title, $page, $u;
if($page=="wml"){
echo "<card id=\"main\" title=\"$title\">";
}else{
$ret .= "<head>\n";
$ret .= "<title>$title</title>\n";
$ret .= "<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"images/favicon.ico\" />\n";
}

return $ret;

}


function CSS(){
global $u;
?>
<style type="text/css">
body {
background-color:#E5E5E5;
color:#000000;
font-family:verdana,arial,helvetica,sans-serif;
font-size:12px;
margin: 0px auto;
padding:2px;
}

a:active, a:visited, a:hover, a:link{
color: #000000;
font-weight: bold;
text-decoration: none;
}

img {
border: 0px none;
}

.button{
background-color:#2994CD;
color:#000000;
}

#container {
padding:0px;
}

#DivTitle{
background-color:#2994CD;
margin-bottom:5px;
margin-top:5px;
padding:2px;
}


#Div{
margin-bottom:5px;
}

#MenuContainer{
margin-bottom:5px;
background-color:#333333;
overflow:hidden;
}

#Menu{
padding:2px;
width:40px;
text-align:center;
float:left;
} 

#Menu a{
color:#FFFFFF;
} 

.active{
background-color:#696969;
}

#TitleMenu{
border:0px solid #000000;
font-size:9px;
}

#Item{
border-bottom: #dadada thin solid;
padding:2px;
clear:both;
}

#Logo{
height:30px;
background-color:#2994CD;
margin:0px;
line-height:30px;
font-size:18px;
color:#FFFFFF;
}

#spanFailed{
color:#FF0000;
}

#spanSuccess{
color:#00FF00;
}

</style>
</head><body>
<?php
}


function Themes(){
global $page;
$theme = new HTML();
echo "".$theme->H()."";
echo "".$theme->T()."";
if($page=="xhtml"){
echo "".$theme->CSS()."";
}
}

function Div($div, $true=FALSE){
global $page;
if($page=="wml"){

if(($div=="D")&&($true==TRUE)){
$ret = "<br/>";

}else if($div=="Foot"){
$ret = "</p></card></wml>";
}else if($div=="container"){
$ret = "<p align=\"left\">";
}else{
$ret = "";
}

}else{
if($div=="D"){
$ret = "</div>";
}else if($div=="Foot"){
$ret = "</body></html>";
}else{
$ret = "<div id=\"$div\">";
}
}
echo $ret;
}

function MenuDiv($class){
global $page, $path;
if($class==1){
$class = "class=\"active\"";
}else if($class==2){
$class2 = "class=\"active\"";
}else if($class==3){
$class3 = "class=\"active\"";
}else if($class==4){
$class4 = "class=\"active\"";
}else if($class==0){
$class4 = "class=\"noactive\"";
}

if($page=="wml"){
$ret = "<a href=\"$path?a=home&amp;ref=home\">Home</a> <a href=\"$path?a=setting\">Setting</a> <a href=\"$path?a=friend\">Friends</a> <a href=\"$path?a=logout\">Logout</a><br/><br/>";
}else{
$ret = "<div id=\"MenuContainer\">";
$ret .= "<div id=\"Menu\" $class>";
$ret .= "<img src=\"images/home.png\" alt=\"Home\" align=\"center\"/><br/>";
$ret .= "<div id=\"TitleMenu\"><a href=\"$path?a=home&amp;ref=home\">Home</a></div>";
$ret .= "</div>";

$ret .= "<div id=\"Menu\" $class2>";
$ret .= "<img src=\"images/setting.png\" alt=\"Setting\" align=\"center\"/><br/>";
$ret .= "<div id=\"TitleMenu\"><a href=\"$path?a=setting\">Setting</a></div>";
$ret .= "</div>";

$ret .= "<div id=\"Menu\" $class3>";
$ret .= "<img src=\"images/buddies.png\" alt=\"Friends\" align=\"center\"/><br/>";
$ret .= "<div id=\"TitleMenu\"><a href=\"$path?a=friend\">Friends</a></div>";
$ret .= "</div>";

$ret .= "<div id=\"Menu\" $class4>";
$ret .= "<img src=\"images/logout.png\" alt=\"Logout\" align=\"center\"/><br/>";
$ret .= "<div id=\"TitleMenu\"><a href=\"$path?a=logout\">Logout</a></div>";
$ret .= "</div>";
$ret .= "</div>";
}

echo $ret;
}

function FootDiv(){
global $page, $u, $a, $path;
if($a=="logout"){
$home = "$path";
}else if(isset($u)){
$home = "$path?a=home&amp;ref=home";

}else{
$home = "$path";
}

if($page=="wml"){
$ret = "<br/>- - -<br/><a href=\"$home\">Home</a> | <a href=\"$path?a=home&amp;ref=help\">Help</a> | <a href=\"$path?a=home&amp;ref=tc\">T &amp; C</a>";
}else{
$ret = "<div id=\"Item\" align=\"center\">";
$ret .= "<a href=\"$home\">Home</a> | <a href=\"$path?a=home&amp;ref=help\">Help</a> | <a href=\"$path?a=home&amp;ref=tc\">T &amp; C</a>";
$ret .= "</div>";
}

echo $ret;

}



function UserDiv(){
global $u, $page;
$ret = "<table width=\"100%\">";
$ret .= "<tr valign=\"top\">";
$ret .= "<td width=\"20\">";
$ret .= "<img src=\"img.jpg\" alt=\"*\" width=\"70\" height=\"60\" border=\"0\"/>";
$ret .= "</td>";
$ret .= "<td width=\"100%\">".id_name($u)."<br/>";
$ret .= "Suke Sangat<br/>";
$ret .= "Mood: Horny<br/>";
$ret .= "Updated";
$ret .= "</td>";
$ret .= "</tr>";
$ret .= "</table>";
echo $ret;
}


function Alert(){
global $u, $path;
$rep = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE unread='1' AND who='".$u."'"));
if($rep[0]>0){
$not = "<a href=\"$path?a=inbox&amp;ref=box&amp;mod=unread\">$rep[0] Inbox</a><br/>";
}


if($page=="wml"){
$ret = "$not";
}else{
$ret = "<div id=\"Item\">";
$ret .= "$not";
$ret .= "</div>";
}
echo $ret;
}



function Paging($path, $p, $np, $npc, $ipp, $ls, $ni){
$nav=' ';
if($p<=3){
$px=1;
$np=$p+3;
}

if($p>3){
$px=$p-3;
$np=$p+3;
}
if($p>=($npc-3)){
$np=$npc;
}
for($jp=$px; $jp<=$np; $jp++){
if($jp==$p){
$nav .= "<span class=\"disable\">[$jp]</span> ";
}else{
$nav .= " <a href=\"$path&amp;p=$jp\">[$jp]</a> ";
}
}
if($p>1){
$pp = $p-1;
$left = "<a href=\"$path&amp;p=$pp\">&#171;Prev</a> ";
}
if($p<$np){
$npg = $p+1;
$right = "<a href=\"$path&amp;p=$npg\">Next&#187;</a>";
}
if($p>4) {
$jp=$p-1;
$first="<a href=\"$path&amp;p=1\">&#171;First</a>";
}else{
$first='';
}
if($p<($npc-3)){
$jp=$p+1;
$last="<a href=\"$path&amp;p=$npc\">Last&#187;</a>";
}else{
$last='';
}
if($ni>$ipp) {
$paging = "Page $p of $npc<br />";
$paging .= "$first  $nav  $last ";
//$paging .= "$left  $right <br/> $first  $nav  $last ";
}

if($ipp>$ni){
$paging .= "Page $np of $np";
}else if($ni==0){
$paging .= "Page 0 of 0";
}





return $paging;

}

}


