<?php

class Inbox{


function ComposeTo($wn, $subject, $message){
global $u;

$w = name_id($wn);
if($w==0){
$ret = "User not exist";
}else{

if(!isignored($u, $w)){

$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(sent) FROM inbox WHERE user='".$u."'"));
$pmfl = $lastpm[0]+5;
if($pmfl<time()){
if(trim($message)!=""){
$txt = parsetext($message);
$nos = substr_count($txt,"<img src=");
if($nos<5){

$res = mysql_query("INSERT INTO inbox SET message='".$message."', subject='".$subject."', user='".$u."', who='".$w."', sent='".time()."'");
if($res) {
$ret = "Inbox success send to ".id_name($w, $u)."";
$last = mysql_fetch_array(mysql_query("SELECT * FROM inbox WHERE user='".$u."' ORDER BY sent DESC"));
//$ret = "PM was sent successfully to $whonick<br/><a href=\"$path?a=read&amp;s=$s&amp;i=$last[id]\">".myTruncate($text, 20)." ...[read sent item]</a>";
}else{
$ret = errorSQL();
}
}else{
$ret = "Only 4 smilies were accepted";
}

}else{
$ret = "Please input some text";
}

}else{
$rema = $pmfl - time();
$ret = "Antiflood control for $rema seconds";
}

}else{
$text = "You has been blacklist by ".id_name($w, $u)."";
}




}

return $ret;
}



function Reply($w, $subject, $text){
global $u;
$whonick = id_name($w, $u);
if(!isignored($u, $w)){
$lastpm = mysql_fetch_array(mysql_query("SELECT MAX(sent) FROM inbox WHERE user='".$u."'"));
$pmfl = $lastpm[0]+5;
if($pmfl<time()){
if(trim($text)!=""){
$txt = parsetext($text);
$nos = substr_count($txt,"<img src=");
if($nos<5){
$res = mysql_query("INSERT INTO inbox SET message='".$text."', subject='".$subject."', user='".$u."', who='".$w."', sent='".time()."'");
if($res) {
$ret = "Inbox success send to ".id_name($w, $u)."";
$last = mysql_fetch_array(mysql_query("SELECT * FROM inbox WHERE user='".$u."' ORDER BY sent DESC"));
//$text = "PM was sent successfully to $whonick<br/><a href=\"$path?a=read&amp;s=$s&amp;i=$last[id]\">".myTruncate($text, 20)." ...[read sent item]</a>";
}else{
$ret = errorSQL();
}
}else{
$ret = "Only 4 smilies were accepted";
}
}else{
$ret = "Please input some text";
}
}else{
$rema = $pmfl - time();
$ret = "Antiflood control for $rema seconds";
}
}else{
$ret = "You has been blacklist by ".id_name($w, $u)."";
}



return $ret;
}


function optionPM($do){
global $i;

if($do=="save"){
$res = mysql_query("UPDATE inbox SET saved='1' WHERE id='".$i."'");
if($res){
$ret = "Inbox saved to folder";
}else{
$ret = errorSQL();
}

}else if($do=="unsave"){
$res = mysql_query("UPDATE inbox SET saved='0' WHERE id='".$i."'");
if($res){
$ret = "Inbox unsaved from folder";
}else{
$ret = errorSQL();
}

}else if($do=="report"){
$res = mysql_query("UPDATE inbox SET reported='1' WHERE id='".$i."'");
if($res){
$ret = "Inbox reported to staff";
}else{
$ret = errorSQL();
}

}



return $ret;
}

}


