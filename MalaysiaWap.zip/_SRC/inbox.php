<?php

$inbox = new Inbox();
$theme->MenuDiv(0);


if($ref!=""){
$theme->Div("Item");
echo "<a href=\"$path?a=inbox\">&#171; Back to Inbox</a>";
$theme->Div("D", true);
}

if($ref==""){
$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=box&amp;mod=unread\">Inbox</a>";
$theme->Div("D", true);

$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=box&amp;mod=read\">Outbox</a>";
$theme->Div("D", true);

$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=box&amp;mod=sent\">Sent</a>";
$theme->Div("D", true);

$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=box&amp;mod=saved\">Saved</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=compose\">Compose Message</a>";
$theme->Div("D", true);
}else if($ref=="box"){

$mod = $_GET["mod"];
if($mod=="")$mod="all";
if($p=="" || $p<=0)$p=1;
$ni = countMessage($mod); //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;

if($ni>0){
if($doit){
$exp = "&amp;rwho=$myid";
}else{
$exp = "";
}

if($mod=="all"){
$sql = "SELECT *  FROM inbox WHERE who='".$u."' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "All messages";
}else if($mod=="sent"){
$sql = "SELECT *  FROM inbox WHERE user='".$u."' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "Sent messages";
}else if($mod=="saved"){
$sql = "SELECT *  FROM inbox WHERE who='".$u."' AND saved='1' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "Archive messages";
}else if($mod=="unread"){
$sql = "SELECT *  FROM inbox WHERE who='".$u."' AND unread='1' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "Unread messages";
}else if($mod=="report"){
$sql = "SELECT *  FROM inbox WHERE who='".$u."' AND reported='1' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "Reported messages";
}else if($mod=="read"){
$sql = "SELECT *  FROM inbox WHERE who='".$u."' AND unread='0' AND saved='0' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "Read messages";


}else{
$sql = "SELECT *  FROM inbox WHERE who='".$u."' ORDER BY sent DESC LIMIT $ls, $ipp";
$title = "All messages";
}
$items = mysql_query($sql);
$i = 0;
echo mysql_error();
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){
if($item[unread]==1){
$st = "[unread]";
}else if($item[unread]==0){
$st = "[read]";
}else if($item[archive]==1){
$st = "[archive]";
}else if($item[reported]==1){
$st = "[reported]";
}

if($item[subject]!=""){
$subject = "$item[subject]";
}else{
$subject = "No subject";
}


$timesent = remaining($item[sent], 1*60*60);

$name = id_name($item[user], $u);
//$out =  "$st<br/><a href=\"profile.$extension?a=m&amp;s=$s&amp;w=$item[sender]\">$name</a><br/>$subject<br/>".myTruncate($item[message], 10)."<br/>$timesent<br/><a href=\"$path?a=read&amp;s=$s&amp;i=$item[id]\">read</a> <a href=\"$path?a=reply&amp;s=$s&amp;i=$item[id]\">reply</a>";
//$out = $theme->UserDiv();
$out = "".avatar($item[user], 15, 15, $name)."$name<br/>$subject<br/>".myTruncate($item[message], 10)."<br/><a href=\"$path?a=inbox&amp;ref=read&amp;i=$item[id]\">Read</a> <a href=\"$path?a=inbox&amp;ref=read&amp;i=$item[id]&amp;do=reply\">Reply</a><br/>$timesent";
$theme->Div("Item");
echo $out;
$theme->Div("D", TRUE);

$i = 1 - $i;


}
}else{
echo errorSQL();
}

$theme->Div("Item");
echo $theme->Paging("$path?a=$a&amp;ref=$ref&amp;mod=$mod", $p, $np, $npc, $ipp, $ls, $ni);
$theme->Div("D", true);

}else{

echo "Sorry, you dont have private message<br/>";

}


}else if($ref=="read"){

if(isset($_POST["submit"])){
echo $inbox->Reply($_POST[who], $_POST["subject"], $_POST["message"]);
echo "<br/>";
}else if($do=="save"){
echo $inbox->optionPM("save");
echo "<br/>";
}else if($do=="unsave"){
echo $inbox->optionPM("unsave");
echo "<br/>";
}else if($do=="report"){
echo $inbox->optionPM("report");
echo "<br/>";
}

$data = mysql_fetch_array(mysql_query("SELECT * FROM inbox WHERE id='".$i."'"));
$theme->Div("Item");

if($u==$data[who]){
$chread = mysql_query("UPDATE inbox SET unread='0' WHERE id='".$i."'");
}

if(($data[who]==$u)||($data[user]==$u)){


if(isset($data[subject])){
$pmsubject = "No Subject";
}else{
$pmsubject = "$pmsubject";
}


$pms = mysql_query("SELECT * FROM inbox WHERE (user=$data[who] AND who=$data[user] AND id='".$i."') OR (user=$data[user] AND who=$data[who] AND id='".$i."') ORDER BY id DESC LIMIT 0,5");
while($pm=mysql_fetch_array($pms)){
$text = parsetext($pm[message], $s);
$sender = id_name($pm[user], $u);
$receive = id_name($pm[who], $u);


echo "Subject: <i>$pmsubject <a href=\"$path?a=$a&amp;s=$s&amp;i=$i&amp;opt=sub\">*</a></i>";


echo "<br/>";

echo "".avatar($pm[sender], 15, 15)." <a href=\"$path?a=profile&amp;w=$pm[user]\">$sender</a><br/>$text";
echo "<br/>";

$timesent = remaining($data[sent], 1*60*60);
echo "$timesent";
echo "<br/>";

}


}
$theme->Div("D", true);

if($do=="reply"){

echo "<form action=\"\" method=\"POST\">";
echo "Message<br/><textarea name=\"message\"></textarea><br/>";
echo "<input type=\"hidden\" name=\"who\" value=\"$data[user]\"/>";
echo "<input type=\"submit\" name=\"submit\" value=\"Reply\" class=\"button\"/></form>";



$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=$ref&amp;i=$i\">Cancel</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=dialog&amp;w=$data[user]\">Dialog</a>";
$theme->Div("D", true);
}else{
$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=$ref&amp;i=$i&amp;do=reply\">Reply</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "<a href=\"$path?a=inbox&amp;ref=dialog&amp;w=$data[user]&amp;i=$data[id]\">Dialog</a>";
$theme->Div("D", true);
$theme->Div("Item");
if($data[saved]==1){
echo "<a href=\"$path?a=inbox&amp;ref=$ref&amp;i=$i&amp;do=unsave\">Unsave</a>";
}else{
echo "<a href=\"$path?a=inbox&amp;ref=$ref&amp;i=$i&amp;do=save\">Save</a>";
}
$theme->Div("D", true);
$theme->Div("Item");
if($data[reported]==1){
echo "Already report";
}else{
echo "<a href=\"$path?a=inbox&amp;ref=$ref&amp;i=$i&amp;do=report\">Report</a>";
}
$theme->Div("D", true);
}



}else if($ref=="dialog"){


if($w==""){
echo "Invalid process data";
}else{
$theme->Div("Item");
echo "Dialog between ".id_name($u, $u)." and ".id_name($w, $u)."";
$theme->Div("D", true);
if($p=="" || $p<=0)$p=1;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE (user=$u AND who=$w AND unread='0') OR (user=$w AND who=$u AND unread='0') ORDER BY sent DESC"));
$ni = $noi[0]; //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;
$sql = "SELECT * FROM inbox WHERE (user=$u AND who=$w AND unread='0') OR (user=$w AND who=$u AND unread='0') ORDER BY sent DESC LIMIT $ls, $ipp";

$items = mysql_query($sql);

echo mysql_error();
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){

$subject = parsetext($item[text], $s);

if(isset($item[subject])){
$subject = "No Subject";
}else{
$subject = $item[subject];
}

$timesent = remaining($item[sent], 1*60*60);
$text = parsetext($item[message]);
$opt = "<a href=\"$path?a=inbox&amp;ref=read&amp;i=$item[id]\">More. .</a>";

if($i==$item[id]){
$flag = "*";
}else{
$flag = "";
}

$out = "$flag Subject: $subject<br/>Messages: $text $opt<br/>$timesent";
$theme->Div("Item");
echo $out;
$theme->Div("D", true);

}
}else{
echo errorSQL();
}

$theme->Div("Item");
echo $theme->Paging("$path?a=$a&amp;ref=$ref&amp;w=$w", $p, $np, $npc, $ipp, $ls, $ni);
$theme->Div("D", true);

}





}else if($ref=="compose"){

if(isset($_POST["submit"])){
echo $inbox->ComposeTo($_POST["who"], $_POST["subject"], $_POST["message"]);
echo "<br/>";
}


$myform = new Form();
$myform->setAction('');
$myform->setMethod('post');
$myform->addField('User', 'who', Form::TYPE_TEXT, 20);
$myform->addField('Subject', 'subject', Form::TYPE_TEXT, 30);
$myform->addField('Message', 'message', Form::TYPE_TXTA, 255);
//$login_type = $myform->addField('Login Type', 'lty', Form::TYPE_SLCT);
//$myform->addOption($login_type,'Visibe', 'v', true);
//$myform->addOption($login_type,'Invisible', 'i', true); //set to false if the form is wml form and not xhtml
$myform->addField('Compose', 'submit', Form::TYPE_SBMT);
echo $myform->getCode(getpage($page));
}else{

echo "Not found";
}


$theme->MenuDiv(0);




function countMessage($view="all"){
global $u;
if($view=="all"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE who='".$u."'"));
}else if($view =="sent"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE user='".$u."' AND saved='0'"));
}else if($view =="saved"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE who='".$u."' AND saved='1'"));
}else if($view =="report"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE who='".$u."' AND reported='1'"));
}else if($view =="unread"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE who='".$u."' AND unread='1'"));
}else if($view =="read"){
$nopm = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM inbox WHERE who='".$u."' AND unread='0' AND saved='0'"));
}
return $nopm[0];
}
?>