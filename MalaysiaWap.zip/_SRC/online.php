<?php


$theme->MenuDiv(0);
$theme->Alert();
$theme->Div("Item");

$timeto = 1*60*60;
$timenw = time();
$timeout = $timenw - $timeto;

$nouo = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM online WHERE actvtime>'".$timeout."'"));
$num = $nouo[0];

if($p=="" || $p<=0)$p=1;
$ni = $num; //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;

$sql = "SELECT
a.id, b.place, a.gender, a.birthdate FROM users a
INNER JOIN online b ON a.id = b.user 
$where 
GROUP BY 1,2
 ORDER BY a.lactive DESC
LIMIT $ls, $ipp
";


$items = mysql_query($sql);
echo mysql_error();
$i = 0;
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){
$name = id_name($item[0], $u);

$out = "<a href=\"$path?a=profile&amp;w=$item[0]\">$name</a><br/>";
echo $out;
$i = 1 - $i;

}
}else{
echo dataEmpty();
}


$theme->Div("D", true);
$theme->MenuDiv(0);
$theme->Div("D");

?>