<?php


$theme->MenuDiv(2);
$theme->Alert();
$theme->Div("Item");
echo "Edit profile";
$theme->Div("D", true);
$theme->Div("Item");
echo "Edit Display";
$theme->Div("D", true);
$theme->Div("Item");
echo "Edit preferences";
$theme->Div("D", true);
$theme->MenuDiv(2);
$theme->Div("D");

?>