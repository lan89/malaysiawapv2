<?php

$res = mysql_query("DELETE FROM session WHERE user='".$u."'");
//$res = mysql_query("UPDATE online SET idle='1' WHERE user='".$u."'");
unset($_SESSION["session"]);

$theme->Div("Item");
echo "You has logged out from this server";
$theme->Div("D", true);


?>