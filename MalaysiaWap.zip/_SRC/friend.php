<?php

$theme->MenuDiv(3);

$theme->Alert();
$theme->Div("Item");
echo "All Online Blacklist";
$theme->Div("D", true);
$theme->Div("Item");
echo "Edit Display";
$theme->Div("D", true);

$theme->MenuDiv(3);

?>