<?php




if(isset($_POST["submit"])){
$user = new User();
$birthdate = "".$_POST["year"]."-".$_POST["month"]."-".$_POST["day"]."";
echo $user->Register($_POST['username'],  $_POST['fname'], $_POST['lname'], $_POST['password'], $_POST['repassword'], $_POST['email'], $_POST['reemail'], $_POST['gender'], $birthdate, $_POST['captcha']);
}
$theme->Div("Item");


echo "<form action=\"\" method=\"POST\">";
echo "Login ID<br/><input type=\"text\" name=\"username\" maxlength=\"15\" class=\"input\"/><br/>";
echo "First Name<br/><input type=\"text\" name=\"fname\" maxlength=\"20\" class=\"input\"/><br/>";
echo "Last Name<br/><input type=\"text\" name=\"lname\" maxlength=\"20\" class=\"input\"/><br/>";
echo "Password<br/><input type=\"password\" name=\"password\" maxlength=\"15\" class=\"input\"/><br/>";
echo "Retype Password<br/><input type=\"password\" name=\"repassword\" maxlength=\"15\" class=\"input\"/><br/>";
echo "E-mail<br/><input type=\"text\" name=\"email\" maxlength=\"50\" class=\"input\"/><br/>";
echo "Retype E-mail<br/><input type=\"text\" name=\"reemail\" maxlength=\"50\" class=\"input\"/><br/>";
echo "Birth Date<br/>";
echo Birthday($bday[2], $bday[1], $bday[0]);
echo "<br/>";
echo "Gender<br/>";
echo "<select name=\"gender\" class=\"input\">";
$valsex = array('M'=>'Male', 'F'=>'Female');
foreach ($valsex as $valueid => $value){
$sex .= "<option value=\"$valueid\">$value</option>";
}
echo $sex;
echo "</select><br/>";
createCaptcha();
echo "Question ".$_SESSION["captchaAlt"]."<br/><input type=\"text\" name=\"captcha\" maxlength=\"3\" class=\"input\"/><br/>";

echo "<input type=\"submit\" name=\"submit\" value=\"Register\" class=\"button\"/></form>";
echo "<br/>";
echo "* All indicated fields required";

$theme->Div("D");

?>