<?php


$user = new User();
$theme->MenuDiv(0);
$theme->Alert();
$theme->Div("Item");
$info = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE id='".$w."'"));
echo "$info[fname] $info[lname]<br/>";
echo avatar($w, 75, 75, id_name($w, $u));
echo "<br/><br/>";
echo "Login ID: $info[username]<br/>";
echo "Birthdate: $info[birthdate]<br/>";
echo "Date Joined: ".date("d-M-y (H:i:s)", $info[regdate])."<br/>";
echo "Last Active: ".date("d-M-y (H:i:s)", $info[lactive])."<br/>";
/*
if($p=="" || $p<=0)$p=1;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM status WHERE user='".$w."'"));
$ni = $noi[0]; //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;
$sql = "SELECT * FROM status WHERE user='".$w."' ORDER BY sent DESC LIMIT $ls, $ipp";

$items = mysql_query($sql);

echo mysql_error();
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){
$statuscom = $user->CountTable("statuscomment", $item[id]);
//echo "<a href=\"$path?a=home&amp;ref=status&amp;i=$item[id]\">$statuscom Comment</a> - $like<br/>";


}
}else{
echo errorSQL();
}
*/
$theme->Div("D", true);
$theme->MenuDiv(0);
$theme->Div("D");

?>