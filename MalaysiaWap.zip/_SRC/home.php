<?php

$user = new User();
if($ref=="home"){
addonline($u, "Home");
$theme->MenuDiv(1);
if(isset($_POST["status"])){
echo $user->Status($_POST["statustext"]);
}

echo "wap maseh terbengkalai, gune lah inbox tu dahulu ye";
$theme->Alert();
/*
$theme->Div("Item");
echo "<big><b>Status</b></big><br/>";
$stat = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM status WHERE user='".$u."'"));
$statlike = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM statuslike WHERE who='".$u."'"));
$status = mysql_fetch_array(mysql_query("SELECT * FROM status WHERE user='".$u."' ORDER BY sent DESC"));


$stlike = mysql_fetch_array(mysql_query("SELECT * FROM statuslike WHERE refid='".$status[id]."'"));

$statuscom = $user->CountTable("statuscomment", $status[id]);
$statuslike = $user->CountTable("statuslike", $status[id]);
if($stat[0]==0){
$mes = "Whats on your mind?";
}else{
$timesent = remaining($status[sent], 1*60*60);
$mes = "$status[text] $timesent";
}


if($do=="status"){
echo "<form action=\"$path??a=home&amp;ref=home\" method=\"POST\">";
echo "$mes<br/>";
echo "<input type=\"text\" name=\"statustext\" class=\"input\" maxlength=\"255\"/><br/>";
echo "<input type=\"submit\" name=\"status\" value=\"Update\" class=\"button\"/><a href=\"$path?a=home&amp;ref=home\">Cancel</a></form> ";
}else{
echo "$mes<br/>";
echo "<a href=\"$path?a=home&amp;ref=$ref&amp;do=status\">Update</a><br/>";
if($stat[0]>0){

if($statlike[0]==0){
$like = "<a href=\"$path?a=home&amp;ref=status&amp;i=$status[id]&amp;do=like\">Like</a>";
}else{
$like = "<a href=\"$path?a=home&amp;ref=status&amp;i=$status[id]&amp;do=unlike&amp;li=$stlike[0]\">Unlike </a>";
}


echo "<a href=\"$path?a=home&amp;ref=status&amp;i=$status[id]\">$statuscom Comment</a> - $like<br/>";
if($statuslike>0){
echo "<a href=\"$path?a=home&amp;ref=statuslike&amp;i=$status[id]\">$statuslike people like this</a>";
}
}
}

$theme->Div("D", true);
*/



$theme->Div("Item");
echo "<b>Shoutbox</b><br/>";


if(isset($_POST["submit"])){
echo "<br/>";
echo addShout($_POST["shout"], $u, $s);
}
echo getShout($u, $s, TRUE);
if(level($u, 1)){
$textmsg = "250";
}else{
$textmsg = "150";
}
echo "<form action=\"$path?a=$a&amp;s=$s\" method=\"post\">";
echo "<input type=\"text\" name=\"shout\" class=\"input\" maxlength=\"$textmsg\"/><br/>";
echo "<input type=\"submit\" name=\"submit\" value=\"Shouted\" class=\"submit\"/></form>";
}


$theme->Div("D", true);

$theme->Div("Item");
echo "<a href=\"$path?a=inbox\">Inbox</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "<a href=\"$path?a=profile&amp;w=$u\">Profile</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "<a href=\"$path?a=online\">Online</a>";
$theme->Div("D", true);
$theme->Div("Item");
echo "Friends";
$theme->Div("D", true);
$theme->Div("Item");
echo "Forums";
$theme->Div("D", true);
$theme->Div("Item");
echo "Chats";
$theme->Div("D", true);
$theme->Div("Item");
echo "Diary";
$theme->Div("D", true);
$theme->MenuDiv(1);

}else if($ref=="status"){
$theme->MenuDiv(1);

if($i==""){
echo "Invalid ref ID";
}else{



if(isset($_POST["submit"])){
echo $user->AddComment("statuscomment", $_POST["comment"], $i);
}else if($do=="like"){
echo $user->AddLike("statuslike", $i);
}else if($do=="unlike"){
echo $user->RemoveLike("statuslike", $_GET["li"]);
}


$data = mysql_fetch_array(mysql_query("SELECT * FROM status WHERE id='".$i."'"));
$theme->Div("Item");
echo "$data[text] ".remaining($data[sent], 1*60*60)."<br/>";

echo "<form action=\"$path??a=home&amp;ref=status&amp;i=$i\" method=\"POST\">";
echo "<input type=\"text\" name=\"comment\" class=\"input\" maxlength=\"255\"/><br/>";
echo "<input type=\"submit\" name=\"submit\" value=\"Comment\" class=\"button\"/></form>";
$theme->Div("D", true);

if($p=="" || $p<=0)$p=1;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM statuscomment WHERE refid='".$i."'"));
$ni = $noi[0]; //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;
$sql = "SELECT * FROM statuscomment WHERE refid='".$i."' ORDER BY sent DESC LIMIT $ls, $ipp";

$items = mysql_query($sql);

echo mysql_error();
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){

$timesent = remaining($item[sent], 1*60*60);
$text = parsetext($item[text]);
$userlink = "<a href=\"$path?a=profile&amp;ref=user&amp;w=$item[who]\">".id_name($item[who], $u, TRUE)."</a>";
$out = "".avatar($item[who], 15, 15)." $userlink $text<br/>$timesent";
$theme->Div("Item");
echo $out;
$theme->Div("D", true);

}
}else{
echo errorSQL();
}

$theme->Div("Item");
echo $theme->Paging("$path?a=$a&amp;ref=$ref&amp;w=$w", $p, $np, $npc, $ipp, $ls, $ni);
$theme->Div("D", true);
}
$theme->MenuDiv(1);

}else if($ref=="statuslike"){
$theme->MenuDiv(1);

if($i==""){
echo "Invalid ref ID";
}else{


$data = mysql_fetch_array(mysql_query("SELECT * FROM status WHERE id='".$i."'"));
$theme->Div("Item");
echo "$data[text] ".remaining($data[sent], 1*60*60)."<br/>";
$theme->Div("D", true);
if($p=="" || $p<=0)$p=1;
$noi = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM statuslike WHERE refid='".$i."'"));
$ni = $noi[0]; //changable
$ipp= 5;
$np = ceil($ni/$ipp);
$npc = ceil($ni/$ipp);
if(($p>$np)&&$p!=1)$p= $np;
$ls = ($p-1)*$ipp;
$sql = "SELECT * FROM statuslike WHERE refid='".$i."' ORDER BY sent DESC LIMIT $ls, $ipp";

$items = mysql_query($sql);

echo mysql_error();
if(mysql_num_rows($items)>0){
while ($item = mysql_fetch_array($items)){

$timesent = remaining($item[sent], 1*60*60);
$text = parsetext($item[text]);

$userlink = "<a href=\"$path?a=profile&amp;ref=user&amp;w=$item[who]\">".id_name($item[who], $u, TRUE)."</a>";
$out = "".avatar($item[who], 15, 15)." $userlink like this<br/>$timesent";
$theme->Div("Item");
echo $out;
$theme->Div("D", true);

}
}else{
echo errorSQL();
}

$theme->Div("Item");
echo $theme->Paging("$path?a=$a&amp;ref=$ref&amp;w=$w", $p, $np, $npc, $ipp, $ls, $ni);
$theme->Div("D", true);
}
$theme->MenuDiv(1);

}else if($ref=="help"){
echo "Help";
}else if($ref=="tc"){
echo "Terms and condition";
}else{

if(isset($u)){
echo "You are already logged in!. <a href=\"$path?a=home&amp;ref=home\">Continue . .</a>";
}else{

if(isset($_GET["do"])){
echo MessageCase($_GET["do"]);
echo "<br/>";
}

echo "<form action=\"login.php\" method=\"POST\">";
echo "Login ID<br/><input type=\"text\" name=\"username\" class=\"input\" maxlength=\"15\"/><br/>";
echo "Password<br/><input type=\"password\" name=\"password\" class=\"input\" maxlength=\"15\"/><br/>";
echo "<input type=\"submit\" name=\"submit\" value=\"Login\" class=\"button\"/></form>";

$theme->Div("DivTitle");
echo "No Account?: <a href=\"$path?a=register\">Join us</a>";
$theme->Div("D");
}
}

?>