<?php
include("inc/func.inc.php");
$username = clean($_POST['username']);
$password = clean($_POST['password']);




if(!db()){
header('Location: index.php?do=1');
exit();
}

$sess = session($_SESSION["session"]);
if(isset($sess)){
header('Location: index.php?a=home&ref=home');
exit();
}

if(trim($username)==""){
header('Location: index.php?do=2');
}else if(trim($password)==""){
header('Location: index.php?do=3');
}else if(checkName($username)==0){
header('Location: index.php?do=4');
}else if(checkInfo($username, $password)==0){
header('Location: index.php?do=5');

}else if(checkInfo($username, $password)==1){

$tm = time();
$xtm = $tm + (1*60*60);
$did = $username.$tm;
$s = md5($did);
$res = mysql_query("INSERT INTO session SET id='".$s."', user='".name_id($username)."', time='".$xtm."'");
$_SESSION['session'] = $s;
header('Location: index.php?a=home&ref=home');
}
exit();


function checkName($username){
$chkname = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE username='".$username."'"));
return $chkname[0];
}

function checkInfo($username, $md5pass){
$checkinfo = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM users WHERE username='".$username."' AND password='".md5($md5pass)."'"));
return $checkinfo[0];
}


?>
