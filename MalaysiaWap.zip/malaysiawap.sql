-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2010 at 01:54 AM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `malaysiawap`
--

-- --------------------------------------------------------

--
-- Table structure for table `blacklist`
--

CREATE TABLE IF NOT EXISTS `blacklist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` int(99) NOT NULL DEFAULT '0',
  `who` int(99) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blacklist`
--


-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE IF NOT EXISTS `inbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(30) NOT NULL,
  `message` blob NOT NULL,
  `user` int(11) NOT NULL,
  `who` int(11) NOT NULL,
  `sent` int(100) NOT NULL DEFAULT '0',
  `unread` char(1) NOT NULL DEFAULT '1',
  `saved` char(1) NOT NULL DEFAULT '0',
  `reported` char(1) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `inbox`
--


-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `actvtime` int(100) NOT NULL DEFAULT '0',
  `place` varchar(50) NOT NULL,
  `placelink` varchar(50) NOT NULL,
  `idle` int(99) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`id`, `user`, `actvtime`, `place`, `placelink`, `idle`) VALUES
(2, 1, 1271646046, 'Home', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `id` varchar(100) NOT NULL,
  `user` int(11) NOT NULL,
  `time` int(100) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `user`, `time`) VALUES
('8c3ad27840e1e4568e81cca44f001d30', 1, 1271647246);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `who` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `who`) VALUES
(1, 'sesexp', '30', '2'),
(2, 'Sat 02 May 2009 - 19:10', '123', '1'),
(3, 'Counter', '1611387', '1'),
(4, 'register', '1', '2'),
(5, 'validate', '0', '2'),
(6, 'pmaf', '5', '3'),
(7, 'shoutaf', '30', '2'),
(8, 'topicaf', '150', '2'),
(9, 'postaf', '50', '2'),
(10, 'commentaf', '15', '2'),
(11, 'sitename', 'TheBluesWAP', '2');

-- --------------------------------------------------------

--
-- Table structure for table `smilies`
--

CREATE TABLE IF NOT EXISTS `smilies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `source` varchar(50) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `smilies`
--


-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `sent` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `status`
--


-- --------------------------------------------------------

--
-- Table structure for table `statuscomment`
--

CREATE TABLE IF NOT EXISTS `statuscomment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` int(11) NOT NULL,
  `refid` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `sent` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statuscomment`
--


-- --------------------------------------------------------

--
-- Table structure for table `statuslike`
--

CREATE TABLE IF NOT EXISTS `statuslike` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` int(11) NOT NULL,
  `refid` int(11) NOT NULL,
  `sent` int(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statuslike`
--


-- --------------------------------------------------------

--
-- Table structure for table `totalonline`
--

CREATE TABLE IF NOT EXISTS `totalonline` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ddt` varchar(20) NOT NULL DEFAULT '',
  `dtm` varchar(20) NOT NULL DEFAULT '',
  `ppl` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `totalonline`
--

INSERT INTO `totalonline` (`id`, `ddt`, `dtm`, `ppl`) VALUES
(1, '16 04 10', '03:20:11 AM', 1),
(2, '19 04 10', '03:00:46 AM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `fb_uid` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` char(1) NOT NULL DEFAULT '1',
  `birthdate` varchar(10) NOT NULL,
  `regdate` int(100) NOT NULL DEFAULT '0',
  `lactive` int(100) NOT NULL DEFAULT '0',
  `totalonline` int(100) NOT NULL DEFAULT '0',
  `smilies` char(1) NOT NULL DEFAULT '1',
  `avatar` varchar(100) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `obrowser` varchar(255) NOT NULL,
  `ipadd` varchar(50) NOT NULL,
  `hidden` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--
